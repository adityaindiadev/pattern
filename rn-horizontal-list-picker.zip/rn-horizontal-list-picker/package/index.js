import React, { useState, useEffect, useRef } from 'react';
import { View, Text, TouchableOpacity, FlatList, ScrollView, Dimensions } from "react-native";


const RNHorizontalListPicker = ({ title = "title", data = ['Alpha', 'Beta', 'Gamma', 'Delta'], onTap = (item, index) => { console.log('click Button Name: ', item, 'index', index) }, showLableTitle = (item, index) => { return item }, disabled = false, isSideTitle = false, sideTitle = '' }) => {

    const [selectedIndex, setselectedIndex] = useState(-1)

    const renderItem = ({ item, index }) => {

        return (
            <TouchableOpacity disabled={disabled} key={String(index)} style={[{ alignSelf: 'center', padding: 12, borderRadius: 10, marginLeft: 5, marginRight: 5 }, { backgroundColor: selectedIndex == index ? 'rgba(52,74,235,1.0)' : 'white' }]} onPress={() => {

                onTap(item, index)
                setselectedIndex(index)

            }}>

                <Text allowFontScaling={false} style={{
                    color: selectedIndex == index ? "white" : 'black',
                    // fontFamily: 
                    fontSize: 13,
                }}> {showLableTitle(item, index)} </Text>

            </TouchableOpacity>
        );
    };




    return (
        <View style={{ display: 'flex', flexDirection: 'column', height: 90, justifyContent: 'center' }}>

            <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>

                <Text allowFontScaling={false} style={{
                    // fontFamily: Constant.MontserratMedium,
                    fontSize: 15,
                }}>{title}</Text>

                {isSideTitle ?

                    <Text allowFontScaling={false} style={{
                        // fontFamily: Constant.MontserratMedium,
                        fontSize: 15,
                    }}>{sideTitle}</Text>
                    : <></>

                }

            </View>


            <FlatList
                data={data}
                renderItem={renderItem}
                showsVerticalScrollIndicator={false}
                keyExtractor={(item, index) => index.toString()}
                horizontal
                nestedScrollEnabled={true}
                showsHorizontalScrollIndicator={false}
            />


        </View>
    );

}

export default RNHorizontalListPicker